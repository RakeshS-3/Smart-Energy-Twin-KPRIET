import pandas as pd
import plotly.express as px
import streamlit as st
from pathlib import Path

st.set_page_config(page_title="Smart Energy Twin | KPRIET", page_icon="⚡", layout="wide")

DATA_PATH = Path(__file__).parent / "data" / "sample_energy.csv"

@st.cache_data
def load_data():
    df = pd.read_csv(DATA_PATH, parse_dates=["timestamp"])
    df["energy_kwh"] = pd.to_numeric(df["energy_kwh"], errors="coerce")
    return df.dropna(subset=["timestamp", "building", "energy_kwh"])

df = load_data()
st.title("⚡ Smart Energy Twin of KPRIET")
st.caption("Campus energy dashboard prototype • Demo data only; not connected to live campus meters.")

with st.sidebar:
    st.header("Dashboard settings")
    buildings = sorted(df["building"].unique().tolist())
    selected = st.multiselect("Select buildings", buildings, default=buildings)
    rate = st.number_input("Electricity tariff (₹/kWh)", min_value=0.0, value=8.0, step=0.5)
    reduction = st.slider("What-if energy reduction (%)", min_value=0, max_value=40, value=10, step=5)

view = df[df["building"].isin(selected)].copy()
if view.empty:
    st.warning("Select at least one building to display the dashboard.")
    st.stop()

total_kwh = view["energy_kwh"].sum()
cost = total_kwh * rate
saved_kwh = total_kwh * reduction / 100
saved_cost = saved_kwh * rate

c1, c2, c3, c4 = st.columns(4)
c1.metric("Total energy", f"{total_kwh:,.0f} kWh")
c2.metric("Estimated cost", f"₹{cost:,.0f}")
c3.metric(f"Potential saving ({reduction}%)", f"{saved_kwh:,.0f} kWh")
c4.metric("Potential cost saving", f"₹{saved_cost:,.0f}")

daily = view.assign(date=view["timestamp"].dt.date).groupby("date", as_index=False)["energy_kwh"].sum()
st.subheader("Energy consumption over time")
st.plotly_chart(px.line(daily, x="date", y="energy_kwh", markers=True,
                        labels={"date": "Date", "energy_kwh": "Energy (kWh)"},
                        title="Daily campus energy use"), use_container_width=True)

building_totals = view.groupby("building", as_index=False)["energy_kwh"].sum().sort_values("energy_kwh", ascending=False)
left, right = st.columns(2)
with left:
    st.subheader("Building-wise consumption")
    st.plotly_chart(px.bar(building_totals, x="building", y="energy_kwh",
                           labels={"building": "Building", "energy_kwh": "Energy (kWh)"},
                           title="Total energy by building"), use_container_width=True)
with right:
    st.subheader("Consumption share")
    st.plotly_chart(px.pie(building_totals, names="building", values="energy_kwh",
                           title="Share of selected energy use"), use_container_width=True)

st.subheader("Selected data")
st.dataframe(view.sort_values("timestamp", ascending=False), use_container_width=True)
st.download_button("Download selected data as CSV",
                   data=view.to_csv(index=False).encode("utf-8"),
                   file_name="campus_energy_selected.csv",
                   mime="text/csv")

st.info("The scenario calculator estimates savings by applying the chosen percentage to the selected data. It is illustrative, not a guaranteed saving forecast.")
