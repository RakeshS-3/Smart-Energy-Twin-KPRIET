# Smart Energy Twin of KPRIET

A student prototype that demonstrates a campus energy digital twin using sample electricity-consumption data. It provides a dashboard for viewing energy use, estimating cost, comparing buildings, and trying simple energy-saving scenarios.

> **Prototype note:** This project uses synthetic demonstration data. It is not connected to KPRIET's live meters or building-management systems.

## Features
- Campus/building energy-consumption dashboard
- Daily and hourly sample data
- Estimated electricity cost
- Building-wise comparison
- Simple energy-saving scenario calculator
- CSV export of the sample dataset

## Tech stack
- Python
- Streamlit
- Pandas
- Plotly

## Run locally
1. Install Python 3.10 or newer.
2. Extract this ZIP and open a terminal in the project folder.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Start the dashboard:
   ```bash
   streamlit run app.py
   ```
5. Open the local URL printed in the terminal.

## Replace demo data with real data
Replace `data/sample_energy.csv` with approved meter readings using the same columns:
- `timestamp`: date/time in ISO format
- `building`: building name
- `energy_kwh`: energy used in kWh

Before using real campus data, obtain permission and validate meter units, time intervals, and data quality.

## Suggested future improvements
- Connect smart meters through an approved API or IoT gateway
- Add weather and occupancy context
- Forecast demand and detect unusual consumption
- Add role-based access and authenticated data ingestion
- Validate savings against a measured baseline

## Repository structure
```text
Smart-Energy-Twin-KPRIET/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
└── data/
    └── sample_energy.csv
```
